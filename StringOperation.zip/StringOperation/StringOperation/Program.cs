﻿using System;
using System.Globalization;

namespace StringOperation
{
    class Program
    {
        static void Main(string[] args)
        {
            /*string str = "helLo hOw arE yoU";*/
            Console.Write("Enter The String Need to be Capitalized: ");

            string str = Console.ReadLine();
            string titleCase = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(str.ToLower());
            //Print The Result
            Console.WriteLine("Capitalized String: " + titleCase);
            Console.ReadKey();
        }
    }
}