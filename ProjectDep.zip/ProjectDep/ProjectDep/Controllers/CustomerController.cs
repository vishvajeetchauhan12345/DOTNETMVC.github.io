﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ProjectDep.Repository.Contact;
using ProjectDep.Repository.Services;
using ProjectDep.Models;

namespace ProjectDep.Controllers
{
    public class CustomerController : Controller
    {
        public ICustomer CustomerService { get; }
        public CustomerController(ICustomer icustomer)
        {
            CustomerService = icustomer;
        }
        public IActionResult Index()
        {
            var cust = CustomerService.GetCustomers();
            return View(cust);
        }
    }
}
