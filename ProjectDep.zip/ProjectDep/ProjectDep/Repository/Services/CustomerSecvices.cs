﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ProjectDep.Models;
using ProjectDep.Repository.Contact;

namespace ProjectDep.Repository.Services
{
    public class CustomerSecvices:ICustomer
    {
        private List<Customer> customers;
        public CustomerSecvices()
        {
            customers = new List<Customer>() 
            { 
            new Customer(){ Id=1,Name="vishvajeet",Gender="male",Email="vishvajeet@gmail.com",Contact=9648202105},
            new Customer(){ Id=2,Name="Abhishek",Gender="male",Email="Abhishek@gmail.com",Contact=9646602105},
            new Customer(){ Id=3,Name="Aditya",Gender="male",Email="Aditya@gmail.com",Contact=9688202105}
            };
        }

        public int CountCustomer()
        {
            return customers.Count;
        }

        public Customer CreateCustomer(Customer customer)
        {
            customers.Add(customer);
            return customer;
        }

        public List<Customer> GetCustomers()
        {
            return customers.ToList();
        }
    }
}
