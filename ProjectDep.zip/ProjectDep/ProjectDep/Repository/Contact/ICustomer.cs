﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ProjectDep.Models;

namespace ProjectDep.Repository.Contact
{
    public interface ICustomer
    {
        Customer CreateCustomer(Customer customer);
        List<Customer> GetCustomers();
        int CountCustomer();
    }
}
